package com.mindtree.ChannelGroupManagementSystem.exception;

public class NoSuchChannelFoundException extends ChannelGroupChannelShowServiceException {

	public NoSuchChannelFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoSuchChannelFoundException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public NoSuchChannelFoundException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public NoSuchChannelFoundException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public NoSuchChannelFoundException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
