package com.mindtree.ChannelGroupManagementSystem.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.ChannelGroupManagementSystem.dto.ChannelDto;
import com.mindtree.ChannelGroupManagementSystem.dto.ChannelGroupDto;
import com.mindtree.ChannelGroupManagementSystem.dto.ShowDto;
import com.mindtree.ChannelGroupManagementSystem.exception.ChannelGroupChannelShowServiceException;

@Service
public interface ChannelGroupChannelService {

	/**
	 * @param channelgroupdto
	 */
	public void insertChannelGroupIntoDB(ChannelGroupDto channelgroupdto);

	/**
	 * @param channeldto
	 * @param channelgroup_id
	 * @throws ChannelGroupChannelShowServiceException
	 */
	public void insertchannelIntoDB(ChannelDto channeldto, int channelgroup_id)
			throws ChannelGroupChannelShowServiceException;

	/**
	 * @param showdto
	 * @param channel_id
	 * @throws ChannelGroupChannelShowServiceException
	 */
	public void insertshowIntoDB(ShowDto showdto, int channel_id) throws ChannelGroupChannelShowServiceException;

	/**
	 * @param channelgroup_id
	 * @return
	 */
	public List<ChannelDto> getAllChannels(int channelgroup_id);
}
