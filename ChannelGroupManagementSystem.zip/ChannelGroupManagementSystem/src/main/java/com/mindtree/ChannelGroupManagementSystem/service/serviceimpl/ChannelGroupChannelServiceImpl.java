package com.mindtree.ChannelGroupManagementSystem.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigurationPackage;
import org.springframework.stereotype.Service;

import com.mindtree.ChannelGroupManagementSystem.dto.ChannelDto;
import com.mindtree.ChannelGroupManagementSystem.dto.ChannelGroupDto;
import com.mindtree.ChannelGroupManagementSystem.dto.ShowDto;
import com.mindtree.ChannelGroupManagementSystem.entity.Channel;
import com.mindtree.ChannelGroupManagementSystem.entity.ChannelGroup;
import com.mindtree.ChannelGroupManagementSystem.entity.Show;
import com.mindtree.ChannelGroupManagementSystem.exception.ChannelGroupChannelShowServiceException;
import com.mindtree.ChannelGroupManagementSystem.exception.NoSuchChannelFoundException;
import com.mindtree.ChannelGroupManagementSystem.exception.NoSuchChannelGroupFoundException;
import com.mindtree.ChannelGroupManagementSystem.repository.ChannelGroupRepository;
import com.mindtree.ChannelGroupManagementSystem.repository.ChannelRepository;
import com.mindtree.ChannelGroupManagementSystem.repository.ShowRepository;
import com.mindtree.ChannelGroupManagementSystem.service.ChannelGroupChannelService;

@Service
public class ChannelGroupChannelServiceImpl implements ChannelGroupChannelService{

	@Autowired
	ChannelGroupRepository channelgrouprepository;
	
	@Autowired
	ChannelRepository channelrepository;
	
	@Autowired
	ShowRepository showrepository;

	@Override
	public void insertChannelGroupIntoDB(ChannelGroupDto channelgroupdto) {
	ChannelGroup channelgroup=new ChannelGroup();
	channelgroup.setChannelgoupId(channelgroupdto.getChannelgoupId());
	channelgroup.setChannelgroupName(channelgroupdto.getChannelgroupName());
	channelgrouprepository.save(channelgroup);	
	}

	@Override
	public void insertchannelIntoDB(ChannelDto channeldto ,int channelgroup_id) throws ChannelGroupChannelShowServiceException {
		int found=0;
	List<ChannelGroup> channelgroups = channelgrouprepository.findAll();
	Channel channel=new Channel();
	for(ChannelGroup ch:channelgroups) {
		if(ch.getChannelgoupId()==channelgroup_id) {
		found=1;
		channel.setChannelId(channeldto.getChannelId());
		channel.setChannelName(channeldto.getChannelName());
		channel.setPrice(channeldto.getPrice());
		channel.setChannelgroup(ch);
		channelrepository.save(channel);
	}
	}
	try {
		if(found==0) {
				throw new NoSuchChannelGroupFoundException("channel group is not present");
				
			}
		}
			catch(NoSuchChannelGroupFoundException e) {
				throw new ChannelGroupChannelShowServiceException(e);
		}
	
	}

	@Override
	public void insertshowIntoDB(ShowDto showdto, int channel_id) throws ChannelGroupChannelShowServiceException {
		int found=0;
	List<Channel> channels=channelrepository.findAll();
	Show show=new Show();
	for(Channel c:channels) {
		if(c.getChannelId()==channel_id) {
			found=1;
			show.setShowId(showdto.getShowId());
			show.setShowName(showdto.getShowName());
			show.setChannel(c);
			showrepository.save(show);
		}
	}
	try {
	if(found==0) {
			throw new NoSuchChannelFoundException("channel is not present");
			
		}
	}
		catch(NoSuchChannelFoundException e) {
			throw new ChannelGroupChannelShowServiceException(e);
	}
	
	}

	@Override
	public List<ChannelDto> getAllChannels(int channelgroup_id) {
	Optional<ChannelGroup> channels=channelgrouprepository.findById(channelgroup_id);
	ChannelGroup c=channels.get();
	List<ChannelDto> channelsdto=new ArrayList<>();
	for(Channel channel:c.getChannel()) {
		ChannelDto channeldto=new ChannelDto();
		channeldto.setChannelId(channel.getChannelId());
		channeldto.setChannelName(channel.getChannelName());
		channeldto.setPrice(channel.getPrice());
		channelsdto.add(channeldto);
	}
	return channelsdto;
	}
	
	
}
	
	
	
		
	
	
	
	

